var path = require('path');

exports.webPort = 3000;
exports.dbconfig = {
	host: 'localhost',
	user: 'root',
	password: 'root',
	database: 'mvvm'
}
