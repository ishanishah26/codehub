var app = angular.module('demoApp', []);
app.service('newService',function($http){
      this.getUser = function()
      {
              $http({
                method: 'GET',
                url: 'http://localhost:3000/getUser',
              }).then(function successCallback(response) {
                console.log("in get user");
                var data = response.data;
                console.log(data);
                    return data;
              }, function errorCallback(response) {
                alert("not found");
            });
      }

});
app.controller('demoCtrl', function($scope,$http,newService) {
  function getUser(){
      $http({
        method: 'GET',
        url: 'http://localhost:3000/getUser',
      }).then(function successCallback(response) {
          $scope.user = response.data;
      }, function errorCallback(response) {
        alert("not found");
    });
    }
    //========================== initializztion ==========================
    $scope.init = function(){
            $scope.user = userJSON;
    }
    $scope.showModalEdit = false;
    //=========================== add new user ===========================
    $scope.addUser = function(params){
            var data = {};
            data.fName = params.fnamei;
            data.lName = params.lnamei;
            data.email = params.emaili;
              $http({
                method: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                url: 'http://localhost:3000/insertUser',
              }).then(function successCallback(response) {
                    $scope.params.fnamei = "";
                    $scope.params.lnamei = "";
                    $scope.params.emaili = "";
                    var user = newService.getUser();
                  // $scope.user =  newService.getUser();
                  console.log("in add user");
                  console.log(user);
              }, function errorCallback(response) {
                alert("not found");
            });
    }
$scope.editUser = function(id,fname,lname,email){
      $scope.user.fnameE = fname;
      $scope.user.idE = id;
      $scope.user.lnameE = lname;
      $scope.user.emailE = email;
      $scope.showModalEdit = !$scope.showModalEdit;
    }
$scope.editUserDb = function(user){
              $scope.showModalEdit = !$scope.showModalEdit;
              var data = {};
              data.userId = user.idE;
              data.fname = user.fnameE;
              data.lname = user.lnameE;
              data.email = user.emailE;
              $http({
                method: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                url: 'http://localhost:3000/editUser/save',
              }).then(function successCallback(response) {
                    getUser();
              }, function errorCallback(response) {
                alert("not found");
            });
        }
$scope.deleteUser = function(id){
        var data = {};
        data.userId = id;
        $http({
              method: 'POST',
              data: JSON.stringify(data),
              contentType: 'application/json',
              url: 'http://localhost:3000/deleteUser',
              }).then(function successCallback(response) {
                            getUser();
              }, function errorCallback(response) {
                        alert("not found");
              });
        }
});

app.directive('modal', function () {
    return {
      template: '<div class="modal fade">' +
          '<div class="modal-dialog">' +
            '<div class="modal-content">' +
              '<div class="modal-header">' +
                '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
                '<h4 class="modal-title">{{ title }}</h4>' +
              '</div>' +
              '<div class="modal-body" ng-transclude></div>' +
            '</div>' +
          '</div>' +
        '</div>',
      restrict: 'E',
      transclude: true,
      replace:true,
      scope:true,

      link: function postLink(scope, element, attrs) {
        scope.title = attrs.title;
        scope.$watch(attrs.visible, function(value){
          if(value == true)
            $(element).modal('show');
          else
            $(element).modal('hide');
        });

        $(element).on('shown.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = true;
          });
        });

        $(element).on('hidden.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = false;
          });
        });
      }
    };
  });
