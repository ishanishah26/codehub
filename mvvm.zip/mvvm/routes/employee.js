var express = require('express');
var router = express.Router();
var emp = require('../model/employemodel');

/* GET home page. */
router.get('/', function(req, res, next) {
  emp.employeeList(function(err,data){
    if(err){
      console.log(err);
    }
    else{
      res.render('employee/index', { empList : data });
    }
  })
  
});

router.get('/list', function(req, res, next) {
  emp.employeeList(function(err,data){
    if(err){
      console.log(err);
    }
    else{
      res.render('employee/index', { empList : data });
    }
  })
  
});

router.get('/create', function(req, res, next) { 
   res.render('employee/upsert', { empData : {} });
});

router.get('/update/:id', function(req, res, next) { 
  console.log(req.params.id);
  emp.employeeById(req.params.id,function(err,data){
    if(err){
      console.log(err);
    }
    else{
      res.render('employee/upsert', { empData : data[0] });
    }
  })
});

router.post('/save', function(req, res, next) { 
		var empObj=JSON.parse(req.body.emp);

  		if(empObj.id==undefined){
  			emp.insert(empObj.empname,empObj.address,empObj.state,empObj.city,empObj.zip,empObj.status,function(err,data){
			    if(err){
			      console.log(err);
			      res.send(500);
			    }
			    else{
			      res.send(200);
			    }
  			})
  		}
  		else{
  			emp.update(empObj.id,empObj.empname,empObj.address,empObj.state,empObj.city,empObj.zip,empObj.status,function(err,data){
			    if(err){
			      console.log(err);
			      res.send(500);
			    }
			    else{
			      res.send(200);
			    }
  			})
  		}
});

module.exports = router;