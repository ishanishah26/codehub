var express = require('express');
var router = express.Router();
var user = require('../model/user');

router.get('/', function(req, res, next) {
            user.getUser(function (err, data) {
                      if (err)
                      {
                                res.end('error occurred');
                                return;
                      }
                      else
                      {
                        res.render('index',{ user: data});
                      }
          });
});

router.get('/getUser', function(req, res, next) {
            user.getUser(function (err, data) {
                      if (err)
                      {
                                res.end('error occurred');
                                return;
                      }
                      else
                      {
                              res.send(data);
                      }
          });
});

router.post('/insertUser', function(req, res, next) {
            user.insertUser(req.body.fName,req.body.lName,req.body.email,function (err, data) {
                      if (err)
                      {
                                res.end('error occurred');
                                return;
                      }
                      else
                      {
                                res.send(data);
                                return;
                      }
          });
});

router.post('/editUser/save', function(req, res, next) {
            user.editUser(req.body.userId,req.body.fname,req.body.lname,req.body.email,function (err, data) {
                      if (err)
                      {
                                res.end('error occurred');
                                return;
                      }
                      else if(data.affectedRows > 0)
                      {
                                res.send(data);
                                return;
                      }
          });
});

router.post('/deleteUser', function(req, res, next) {
            user.deleteUser(req.body.userId,function (err, data) {
                      if (err)
                      {
                                res.end('error occurred');
                                return;
                      }
                      else
                      {
                                res.send(data);
                                return;
                      }
          });
});

module.exports = router;
