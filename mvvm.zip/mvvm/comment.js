&nbsp;&nbsp;First name : <input type="text" ng-model="user.firstName"/>
<br/>
<br/>
&nbsp;&nbsp;Last name  : <input type="text" ng-model="user.lastName"/>
<hr/>
&nbsp;&nbsp;Full Name: {{user.firstName + " " + user.lastName}}
<hr/>
// function getUser(){
//     $http({
//       method: 'GET',
//       url: 'http://localhost:3000/getUser',
//     }).then(function successCallback(response) {
//         $scope.user = response.data;
//     }, function errorCallback(response) {
//       alert("not found");
//   });
//   }
