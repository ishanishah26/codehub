var sql = require('../config/sql');

exports.getUser  = function(callback) {
	var query = 'SELECT * from user';
					sql.executeSql(query,function(err, data){
								if(!err)
								{
										callback(null, data);
								}
								else
								{
											callback(err,null);
								}
					});
			}

exports.insertUser  = function(fname,lname,email,callback) {
				var query = 'Insert into user(fname,lname,email) values("'+ fname +'","'+ lname +'","'+ email +'")';
								sql.executeSql(query,function(err, data){
											if(!err)
											{
													callback(null, data);
											}
											else
											{
														callback(err,null);
											}
								});
}

exports.editUser  = function(id,fname,lname,email,callback) {
				var query = 'UPDATE user SET fname = "'+ fname +'",lname = "'+ lname +'",email = "'+ email +'" WHERE userId = "'+ id +'"';
								sql.executeSql(query,function(err, data){
											if(!err)
											{
													callback(null, data);
											}
											else
											{
														callback(err,null);
											}
								});
}

exports.deleteUser  = function(id,callback) {
				var query = 'Delete from user WHERE userId = "'+ id +'"';
								sql.executeSql(query,function(err, data){
											if(!err)
											{
													callback(null, data);
											}
											else
											{
														callback(err,null);
											}
								});
}
