var sql = require('../config/sql');

exports.employeeList=function(callback){
	var query="SELECT * FROM emp";
	sql.executeSql(query,function(err, data){
		if(!err)
		{
			callback(null, data);
		}
		else
		{
			callback(err,null);
		}
	});
}

exports.employeeById=function(empId,callback){
	var query="SELECT * FROM emp WHERE id="+empId;
	sql.executeSql(query,function(err, data){
		if(!err)
		{
			callback(null, data);
		}
		else
		{
			callback(err,null);
		}
	});
}

exports.insert=function(empname,address,state,city,zip,status,callback){
	var query="INSERT INTO emp(empname,address,state,city,zip,status)"+
		  "VALUES('"+empname+"','"+address+"','"+state+"','"+city+"','"+zip+"','"+status+"')"
	sql.executeSql(query,function(err, data){
		if(!err)
		{
			callback(null, true);
		}
		else
		{
			callback(err,null);
		}
	});
}

exports.update=function(id,empname,address,state,city,zip,status,callback){
	var query=" UPDATE emp"+
			  " SET empname='"+empname+"',address='"+address+"',state='"+state+"',city='"+city+"',zip='"+zip+"',status='"+status+"'"+
			  " WHERE id="+id
	sql.executeSql(query,function(err, data){
		if(!err)
		{
			callback(null, true);
		}
		else
		{
			callback(err,null);
		}
	});
}