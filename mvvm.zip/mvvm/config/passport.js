var multer = require('multer');
var mysql = require('mysql');
var connection = require('./database');
var bcrypt = require('bcryptjs');
var LocalStrategy = require('passport-local').Strategy;

//coonetion

var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection");
	else
	console.log("error in connection");
	});
module.exports = function(passport) {
	var salt = bcrypt.genSaltSync(10);

    passport.serializeUser(function(user, done) {
        done(null, user.id);
    });

    // used to deserialize the user
    passport.deserializeUser(function(id, done) {
        connect.query("SELECT id, email FROM user WHERE id = ? ",[id], function(err, rows){
            done(err, rows[0]);
        });
    });

 passport.use(
        'local-signin',
        new LocalStrategy({
            // by default, local strategy uses username and password, we will override with email
            usernameField : 'email',
            passwordField : 'password',
            passReqToCallback : true
        },
        function(req, username, password, done) {
							var path = req.file.path;
							var image_path = path.substring(6);
	            connect.query("SELECT * FROM user WHERE email = ?",[username], function(err, rows) {
                if (err)
                    return done(err);
                if (rows.length) {
                    return done(null, false, req.flash('signupMessage', 'That username is already taken.'));
                } else {
                    var newUser = {
												name: req.body.uname,
                        email: username,
                        password: bcrypt.hashSync(password, salt),
                        dob: req.body.dob,
                        image: image_path
                    };
                    var insertQuery = "INSERT INTO user ( name, email, password, date_birth, image ) values (?,?,?,?,?)";

                    connect.query(insertQuery,[newUser.name, newUser.email, newUser.password, newUser.dob, newUser.image],function(err, rows) {
                        newUser.id = rows.insertId;

                        return done(null, newUser);
                    });
                }
            });
        })
    );

passport.use(
        'local-login',
        new LocalStrategy({
            usernameField : 'email',
            passwordField : 'password',
            passReqToCallback : true
			},
        function(req, username, password, done) {
            connect.query("SELECT * FROM user WHERE email = ?",[username], function(err, rows){
                if (err)
                    return done(err);
                if (!rows.length) {
                    return done(null, false, req.flash('loginMessage', 'No user found.'));
                }
                else
                {
					if (!bcrypt.compareSync(password, rows[0].password))
						return done(null, false, req.flash('loginMessage', 'Oops! Wrong password.'));
						return done(null, rows[0]);
				}
            });
        })
    );

}
